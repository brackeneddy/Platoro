**To get the details of a Usage Plan**

Command::

  aws apigateway get-usage-plan --usage-plan-id a1b2c3
